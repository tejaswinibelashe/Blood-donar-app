package com.bloodlink.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloodLinkApplication {

    static void main(String[] args) {
        SpringApplication.run(BloodLinkApplication.class, args);
    }
}
